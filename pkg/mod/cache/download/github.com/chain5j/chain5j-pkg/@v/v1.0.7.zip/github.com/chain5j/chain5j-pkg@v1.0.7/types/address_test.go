// Package types
//
// @author: xwc1125
package types

import (
	"testing"
)

func TestAddress_FromStr(t *testing.T) {
	// hexAddress := NewHexAddress()
	// newHexAddress, err := hexAddress.FromStr("0x9254E62FBCA63769DFd4Cc8e23f630F0785610CE")
	// fmt.Println(newHexAddress.String())
	// newHexAddress2, err := hexAddress.FromStr("0x9254e62FBCA63769DFd4Cc8e23f630F0785610CE")
	// fmt.Println(newHexAddress2.String())
	//
	// domainAddress, err := NewDomainAddress(&hexAddress)
	// if err != nil {
	//	panic(err)
	// }
	// newDomainAddress, err := domainAddress.FromStr("0x9254E62FBCA63769DFd4Cc8e23f630F0785610CE")
	// fmt.Println(newDomainAddress.String())
	// newDomainAddress2, err := domainAddress.FromStr("0x9254e62FBCA63769DFd4Cc8e23f630F0785610CE")
	// fmt.Println(newDomainAddress2.String())
	//
	// marshal, err := json.Marshal(newDomainAddress)
	// if err != nil {
	//	panic(err)
	// }
	// fmt.Println("json.Marshal", string(marshal))
	// err = json.Unmarshal(marshal, &domainAddress)
	// if err != nil {
	//	panic(err)
	// }
	// fmt.Println("domainAddress", domainAddress)
}
