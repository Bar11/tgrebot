// Package tree
//
// @author: xwc1125
package tree

import log "github.com/chain5j/logger"

func logger() log.Logger {
	return log.Log("tree")
}
