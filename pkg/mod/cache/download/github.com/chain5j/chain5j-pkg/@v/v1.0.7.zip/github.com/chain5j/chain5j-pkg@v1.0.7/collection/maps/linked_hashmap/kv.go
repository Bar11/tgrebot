// Package linkedHashMap
//
// @author: xwc1125
package linkedHashMap

type KV struct {
	Key interface{}
	Val interface{}
}
