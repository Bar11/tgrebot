// Package hashmap
//
// @author: xwc1125
package hashmap

// KV ...
type KV struct {
	Key   string
	Value interface{}
}
