// Package scrypt
//
// @author: xwc1125
package scrypt

import "errors"

var (
	ErrDecrypt = errors.New("could not decrypt key with given password")
)
