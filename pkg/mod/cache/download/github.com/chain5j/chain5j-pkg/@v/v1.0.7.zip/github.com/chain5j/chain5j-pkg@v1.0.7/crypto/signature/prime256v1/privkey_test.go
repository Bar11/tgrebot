// Package prime256v1
//
// @author: xwc1125
package prime256v1

import "testing"

func TestGenerateKey(t *testing.T) {
}
