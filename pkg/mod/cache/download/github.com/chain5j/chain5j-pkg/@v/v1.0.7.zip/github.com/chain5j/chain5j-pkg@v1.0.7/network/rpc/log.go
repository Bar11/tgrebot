// Package rpc
//
// @author: xwc1125
package rpc

import (
	"github.com/chain5j/logger"
)

func log15() logger.Logger {
	return logger.New("rpc")
}
