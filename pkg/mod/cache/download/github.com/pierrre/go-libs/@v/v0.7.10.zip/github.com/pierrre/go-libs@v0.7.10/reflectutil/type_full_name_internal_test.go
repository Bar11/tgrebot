package reflectutil

var TypeFullNameInternal = typeFullName
