// Package reflectutil provides utility functions for the reflect package.
package reflectutil
