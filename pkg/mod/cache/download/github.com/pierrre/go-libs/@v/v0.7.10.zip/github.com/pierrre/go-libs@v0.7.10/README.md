# Go libs

Go libraries shared by my projects.

[![Go Reference](https://pkg.go.dev/badge/github.com/pierrre/go-libs.svg)](https://pkg.go.dev/github.com/pierrre/go-libs)
